﻿Imports System.Data.SqlClient
Partial Class custinfo
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        If Session("name") = "" Then
            Response.Redirect("LOGIN.aspx")

        End If
    End Sub

  
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Text_cname.Text = ""
        Text_add.Text = ""
        Text_mob.Text = ""

    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Response.Redirect("Mesurment.aspx")
    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        cn = New SqlConnection(ConfigurationManager.ConnectionStrings("tailortent").ConnectionString)
        cn.Open()
        cmd = New SqlCommand("insert into tbl_custinfo values('" & Text_cname.Text & "','" & Text_add.Text & "','" & Text_mob.Text & "','" & Calendar2.SelectedDate & "','" & Calendar1.SelectedDate & "')", cn)

        cmd.ExecuteNonQuery()
        MsgBox("RECORD INSERTED..!!")
    End Sub
End Class
