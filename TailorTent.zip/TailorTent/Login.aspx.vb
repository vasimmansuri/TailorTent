﻿Imports System.Data.SqlClient
Partial Class Login
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cn = New SqlConnection(ConfigurationManager.ConnectionStrings("tailortent").ConnectionString)
        cn.Open()
        cmd = New SqlCommand("select name,password from tbl_registration where name='" & Text_uname.Text & "'and password='" & Text_pass.Text & "'", cn)
        dr = cmd.ExecuteReader
        If (dr.HasRows) Then
            Session("name") = Text_uname.Text

            Response.Redirect("custinfo.aspx")
        Else
            MsgBox("PLEASE ENTER VALID USERNAME OR PASSWORD..!!")
        End If

    End Sub
End Class
