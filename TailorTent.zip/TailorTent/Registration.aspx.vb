﻿Imports System.Data.SqlClient

Partial Class Registration
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Textuname.Text = ""
        Textpass.Text = ""
        Textans.Text = ""
        Textorg.Text = ""
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cn = New SqlConnection(ConfigurationManager.ConnectionStrings("tailortent").ConnectionString)
        cn.Open()
        cmd = New SqlCommand("insert into tbl_registration values('" & Textuname.Text & "','" & Textpass.Text & "','" & Textorg.Text & "','" & DropDownList1.SelectedValue & "','" & Textans.Text & "')", cn)
        cmd.ExecuteNonQuery()
        MsgBox("REGISTRATION SUCCESSFULL....!!")
        Response.Redirect("Login.aspx")

    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
End Class
