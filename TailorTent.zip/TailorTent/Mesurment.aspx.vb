﻿Imports System.Data.SqlClient
Partial Class Mesurment
   
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("name") = "" Then
            Response.Redirect("LOGIN.aspx")

        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Text_chest.Text = ""
        Text_drain.Text = ""
        Text_hipps.Text = ""
        Text_hipps2.Text = ""
        Text_khistak.Text = ""
        Text_length.Text = ""
        Text_mundho.Text = ""
        Text_nback.Text = ""
        Text_nback2.Text = ""
        Text_nfront.Text = ""
        Text_nfront2.Text = ""
        Text_sleeve.Text = ""
        Text_sleeve2.Text = ""
        Text_slength.Text = ""
        Text_sold.Text = ""
        Text_waist1.Text = ""
        Text_waist2.Text = ""
        Text_yog.Text = ""

    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
       
        Response.Redirect("iteminfo.aspx")
    End Sub

    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        cn = New SqlConnection(ConfigurationManager.ConnectionStrings("tailortent").ConnectionString)
        cn.Open()
        cmd = New SqlCommand("('select cust_id from tbl_custinfo ')", cn)
        HiddenField1.Value = cmd.ExecuteNonQuery()
        cmd = New SqlCommand("insert into tbl_mesurment values('" & HiddenField1.Value & "','" & Text_length.Text & "','" & Text_waist1.Text & "','" & Text_hipps.Text & "','" & Text_mundho.Text & "','" & Text_sleeve.Text & "','" & Text_nfront.Text & "','" & Text_nback.Text & "','" & Text_sold.Text & "','" & Text_chest.Text & "','" & Text_hipps2.Text & "','" & Text_waist2.Text & "','" & Text_sleeve2.Text & "','" & Text_nfront2.Text & "','" & Text_nback2.Text & "','" & Text_slength.Text & "','" & Text_drain.Text & "','" & Text_khistak.Text & "','" & Text_yog.Text & "')", cn)
        cmd.ExecuteNonQuery()
        MsgBox("RECORD INSERTED...!!")
    End Sub
End Class
