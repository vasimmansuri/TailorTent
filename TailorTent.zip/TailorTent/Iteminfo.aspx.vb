﻿Imports System.Data.SqlClient
Partial Class Iteminfo
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim a As Double
    Dim b As Double
    Dim c As Double
    Public i As Double

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("name") = "" Then
            Response.Redirect("LOGIN.aspx")
           
        End If
      

    End Sub

   
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
       
        Text_desc.Text = ""
        Text_price.Text = ""
        Text_quan.Text = ""
        Text_total.Text = ""
    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        cn = New SqlConnection(ConfigurationManager.ConnectionStrings("tailortent").ConnectionString)
        cn.Open()
        a = Convert.ToDouble(Text_quan.Text.ToString())
        b = Convert.ToDouble(Text_price.Text.ToString())
        c = (a * b)
        Text_total.Text = c
        cmd = New SqlCommand("insert into tbl_item values('" & Text_desc.Text & "','" & Text_quan.Text & "','" & Text_price.Text & "','" & Text_total.Text & "','" & RadioButtonList1.SelectedItem.Text & "')", cn)
        cmd.ExecuteNonQuery()
        MsgBox("RECORD INSERTED..!!")
    End Sub

    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("THANK YOU...!!")
    End Sub
End Class
