﻿
Partial Class HomePage
    Inherits System.Web.UI.MasterPage
End Class

